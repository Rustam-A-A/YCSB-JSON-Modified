//package site.ycsb.postgrenosql;
//
///**
// * PostgreNoSQL client for YCSB framework.
// */
//public final class App {
//  public static void main(String[] args) {
//    ObjectToJSON object = new ObjectToJSON();
//    String json = object.objectToJson();
//    System.out.println(json);
//  }
//}